import argparse
import os

import datajoint as dj
from dotenv import find_dotenv, load_dotenv


def load_env_vars(env_file=None,
                  required_vars=None,
                  optional_vars=None,
                  raise_on_missing=True,
                  override=False,
                  verbose=True):
    """
    Load and validate environment variables from .env file.
    
    :param env_file: path to .env file. If None, searches for .env file starting from current directory
    :param required_vars: list of required environment variable names
    :param optional_vars: list of optional environment variable names
    :param raise_on_missing: whether to raise an error if required variables are missing
    :param override: whether to override existing environment variables with values from .env file
    :return: dict of environment variables
    """
    if env_file is None:
        env_file = find_dotenv(usecwd=True)

    print("Using .env file:", env_file) if verbose else None
    load_dotenv(
        env_file,
        verbose=verbose,
        override=override,
    )

    if required_vars is None and optional_vars is None:
        required_vars = [
            "DATAJOINT_DB_HOST", "DATAJOINT_DB_USER", "DATAJOINT_DB_PASSWORD",
            "DATAJOINT_SCHEMA_NAME"
        ]
        optional_vars = []

    if required_vars is None:
        required_vars = []

    if optional_vars is None:
        optional_vars = []

    # Collect environment variables
    env_vars = {}

    # Load required variables
    for var in required_vars:
        env_vars[var] = os.getenv(var)

    # Load optional variables
    for var in optional_vars:
        env_vars[var] = os.getenv(var)

    # Check that all required environment variables are set
    missing_vars = [key for key in required_vars if env_vars[key] is None]
    if missing_vars and raise_on_missing:
        raise ValueError(
            f"Missing required environment variables: {missing_vars}")

    # Print loaded variables (excluding password for security)
    if verbose:
        for key, value in env_vars.items():
            if "PASSWORD" in key.upper():
                print(f"{key}: {'***' if value else None}")
            else:
                print(f"{key}: {value}")

    return env_vars


def connect_to_database(
    host=None,
    user=None,
    password=None,
    *,
    reset=False,
    **load_env_kwargs,
):
    """
    Returns a persistent connection object to be shared by multiple modules.
    If the connection is not yet established or reset=True, a new connection is set up.
    If connection information is not provided, it is taken from .env file.
    
    :param host: hostname (with optional port as host:port)
    :param user: mysql user
    :param password: mysql password
    :param reset: whether the connection should be reset or not
    :return: dict of environment variables used for connection
    """

    # only establish connection if it is not already established or reset is True
    if not hasattr(dj.conn, "connection") or reset:

        # Load environment variables as defaults.
        # With override=False, this respects existing env vars.
        env_vars = load_env_vars(
            optional_vars=[
                "DATAJOINT_DB_HOST",
                "DATAJOINT_DB_USER",
                "DATAJOINT_DB_PASSWORD",
                "DATAJOINT_SCHEMA_NAME",
            ],
            raise_on_missing=False,
            **load_env_kwargs,
        )

        # Use provided parameters or fall back to environment variables
        host = host if host is not None else env_vars.get("DATAJOINT_DB_HOST")
        user = user if user is not None else env_vars.get("DATAJOINT_DB_USER")
        password = password if password is not None else env_vars.get(
            "DATAJOINT_DB_PASSWORD")

        # Check that all required environment variables are set
        if not all([host, user, password]):
            missing_vars = []
            if not host:
                missing_vars.append("DATAJOINT_DB_HOST")
            if not user:
                missing_vars.append("DATAJOINT_DB_USER")
            if not password:
                missing_vars.append("DATAJOINT_DB_PASSWORD")
            raise ValueError(
                f"Missing required environment variables: {missing_vars}")

        # Parse host and port if host contains port
        if host and ":" in host:
            host_part, port_part = host.split(":", 1)
            dj.config["database.host"] = host_part
            dj.config["database.port"] = int(port_part)
        else:
            dj.config["database.host"] = host

        # Configure DataJoint
        dj.config["database.user"] = user
        dj.config["database.password"] = password
        dj.config["enable_python_native_blobs"] = True

        # Establish connection using DataJoint's conn function
        dj.conn(reset=reset)

    else:
        # connection already established, but we still need to ensure required vars are present
        env_vars = load_env_vars(
            optional_vars=[
                "DATAJOINT_SCHEMA_NAME",
                "DATAJOINT_DB_HOST",
                "DATAJOINT_DB_USER",
                "DATAJOINT_DB_PASSWORD",
            ],
            **load_env_kwargs,
        )

    return env_vars


def main():
    """Parse command line arguments and connect to the database."""
    parser = argparse.ArgumentParser(
        description="Connect to DataJoint database.")
    parser.add_argument(
        "--host",
        help="Hostname of the database server (e.g., 'localhost:3306').")
    parser.add_argument("--user", help="Username for the database.")
    parser.add_argument("--password", help="Password for the database.")
    parser.add_argument("--reset",
                        action="store_true",
                        help="Force reset the connection if it exists.")
    args = parser.parse_args()

    connect_to_database(
        host=args.host,
        user=args.user,
        password=args.password,
        reset=args.reset,
    )


if __name__ == "__main__":
    main()
