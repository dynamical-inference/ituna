import pandas as pd
import random
import string
from datetime import datetime


def flatten_dict(d: dict, parent_key: str = '', sep: str = '__') -> dict:
    """
    Recursively flatten a nested dictionary, joining keys with a separator.
    
    Args:
        d: Dictionary to flatten
        parent_key: Key prefix for the current level (used in recursion)
        sep: Separator to use when joining nested keys
    
    Returns:
        Flattened dictionary where nested keys are joined with the separator
        
    Example:
        >>> nested = {'a': {'b': 1, 'c': 2}, 'd': 3}
        >>> flatten_dict(nested)
        {'a__b': 1, 'a__c': 2, 'd': 3}
    """
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        elif isinstance(v, (list, tuple)):
            # Handle lists and tuples that may contain dicts
            flattened_collection = []
            for i, item in enumerate(v):
                if isinstance(item, dict):
                    # Flatten the dict and add index to key
                    flattened_item = flatten_dict(item,
                                                  f"{new_key}{sep}{i}",
                                                  sep=sep)
                    items.extend(flattened_item.items())
                else:
                    flattened_collection.append(item)
            # Only add the collection if it has non-dict items
            if flattened_collection:
                items.append((new_key, type(v)(flattened_collection)))
        else:
            items.append((new_key, v))
    return dict(items)


def unflatten_dict(d: dict, sep: str = '__') -> dict:
    """
    Reconstruct a nested dictionary from a flattened dictionary.
    
    Args:
        d: Flattened dictionary with keys joined by separator
        sep: Separator used to join nested keys
    
    Returns:
        Nested dictionary with original structure restored
        
    Example:
        >>> flattened = {'a__b': 1, 'a__c': 2, 'd': 3}
        >>> unflatten_dict(flattened)
        {'a': {'b': 1, 'c': 2}, 'd': 3}
    """
    result_dict = {}
    for k, v in d.items():
        parts = k.split(sep)
        d = result_dict
        for p in parts[:-1]:
            if p not in d:
                d[p] = {}
            d = d[p]
        d[parts[-1]] = v
    return result_dict


def list_to_tuple_recursive(x):
    if isinstance(x, list):
        return tuple(list_to_tuple_recursive(i) for i in x)
    elif isinstance(x, dict):
        return {k: list_to_tuple_recursive(v) for k, v in x.items()}
    return x


def flatten_dataframe(df: pd.DataFrame,
                      column_name_replacements: dict = None,
                      flatten_separator: str = ".",
                      dict_detection_method: str = "any",
                      convert_lists_to_tuples: bool = True,
                      inplace: bool = False,
                      specific_columns: list = None):
    """
    Flatten nested dictionaries within DataFrame columns and expand them into separate columns.
    
    This function processes a DataFrame by:
    1. Converting specified patterns in column names (default: double underscores to dots)
    2. Finding columns that contain dictionary values
    3. Flattening those dictionaries and creating new columns for each key
    4. Optionally converting any list values to tuples to make them hashable
    
    Args:
        df: DataFrame containing columns with dictionary values to be flattened
        column_name_replacements: Dict of {old_pattern: new_pattern} for column name replacements.
                                Defaults to {"__": "."} if None.
        flatten_separator: Separator to use when flattening nested dictionaries. Default: "."
        dict_detection_method: Method to detect dict columns. Options: "any" (any row contains dict),
                             "all" (all rows contain dict), "first" (first row contains dict). Default: "any"
        convert_lists_to_tuples: Whether to convert lists to tuples for hashability. Default: True
        inplace: Whether to modify the DataFrame in place. Default: False
        specific_columns: List of specific columns to process. If None, processes all columns. Default: None
        
    Returns:
        DataFrame with dictionary columns expanded into separate columns
        
    Note:
        This function modifies column names and creates new columns based on
        dictionary keys found in the data. Lists are converted to tuples
        for hashability if convert_lists_to_tuples is True.
    """
    if not inplace:
        df = df.copy()

    # Apply column name replacements
    if column_name_replacements is None:
        column_name_replacements = {"__": "."}

    for old_pattern, new_pattern in column_name_replacements.items():
        df.columns = [
            col.replace(old_pattern, new_pattern) for col in df.columns
        ]

    # Determine which columns to process
    columns_to_check = specific_columns if specific_columns is not None else df.columns

    # Find columns containing dicts based on detection method
    dict_columns = []
    for col in columns_to_check:
        if col not in df.columns:
            continue

        if dict_detection_method == "any":
            has_dict = df[col].apply(lambda x: isinstance(x, dict)).any()
        elif dict_detection_method == "all":
            has_dict = df[col].apply(lambda x: isinstance(x, dict)).all()
        elif dict_detection_method == "first":
            has_dict = isinstance(df[col].iloc[0],
                                  dict) if len(df) > 0 else False
        else:
            raise ValueError(
                f"Invalid dict_detection_method: {dict_detection_method}")

        if has_dict:
            dict_columns.append(col)

    # Process each dict column
    for col in dict_columns:
        # Flatten nested dicts
        df[col] = df[col].apply(lambda x: flatten_dict(
            x, sep=flatten_separator) if isinstance(x, dict) else x)

        # Extract flattened keys into separate columns
        # Collect all unique keys across all rows
        all_keys = set()
        for d in df[col]:
            if isinstance(d, dict):
                all_keys.update(d.keys())

        # Create new columns for each unique key
        for key in all_keys:
            df[f"{col}{flatten_separator}{key}"] = df[col].apply(
                lambda x: x.get(key, None) if isinstance(x, dict) else None)

        del df[col]
        df = df.copy()

    # Convert lists to tuples if requested
    if convert_lists_to_tuples:
        for col in df.columns:
            # Check if any element in that col is a list
            if len(df) > 0 and isinstance(df[col].iloc[0], list):
                df[col] = df[col].apply(lambda x: list_to_tuple_recursive(x))

    return df


def unique_timestamp():
    """
    Generate a unique timestamp string combining current datetime and random ID.
    
    Creates a timestamp in the format "YYYY-MM-DD_HH-MM-SS_randomid" where
    randomid is a 6-character string of lowercase letters and digits.
    
    Returns:
        str: Unique timestamp string
        
    Example:
        >>> timestamp = unique_timestamp()
        >>> print(timestamp)  # e.g., "2024-01-15_14-30-45_a7b9c2"
    """
    # Reset random seed to ensure unique timestamps
    random.seed()
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    unique_id = ''.join(
        random.choices(string.ascii_lowercase + string.digits, k=6))
    return timestamp + '_' + unique_id


def make_json_serializable(
        obj,
        convert_tensors: bool = True,
        convert_numpy: bool = True,
        convert_sets: bool = True,
        convert_tuples: bool = True,
        handle_errors: str = "warn",  # "warn", "raise", "delete"
        max_depth: int = 10,
        _current_depth: int = 0):
    """
    Convert an object to a JSON-serializable format.
    
    Recursively processes nested dictionaries, lists, and other containers to ensure
    all elements can be serialized to JSON. Handles common non-serializable types
    like torch tensors, numpy arrays, sets, and tuples.
    
    Args:
        obj: The object to convert
        convert_tensors (bool): Convert torch tensors to lists using .tolist()
        convert_numpy (bool): Convert numpy arrays to lists using .tolist()
        convert_sets (bool): Convert sets to lists
        convert_tuples (bool): Convert tuples to lists
        handle_errors (str): How to handle conversion errors:
            - "warn": Print warning and keep original value
            - "raise": Raise the exception
            - "delete": Remove the problematic key/value
        max_depth (int): Maximum recursion depth to prevent infinite loops
        _current_depth (int): Internal parameter for tracking recursion depth
        
    Returns:
        JSON-serializable version of the input object
        
    Raises:
        RecursionError: If max_depth is exceeded
        Exception: If handle_errors="raise" and conversion fails
        
    Example:
        >>> import torch
        >>> import numpy as np
        >>> data = {
        ...     "tensor": torch.tensor([1, 2, 3]),
        ...     "array": np.array([4, 5, 6]),
        ...     "set": {7, 8, 9},
        ...     "nested": {"inner_tensor": torch.tensor([[1, 2], [3, 4]])}
        ... }
        >>> serializable = make_json_serializable(data)
        >>> import json
        >>> json.dumps(serializable)  # This will work
    """
    if _current_depth > max_depth:
        raise RecursionError(f"Maximum recursion depth {max_depth} exceeded")

    # Handle None and basic JSON-serializable types
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj

    try:
        # Handle torch tensors
        if convert_tensors and hasattr(obj, 'tolist') and 'torch' in str(
                type(obj)):
            return obj.tolist()

        # Handle numpy arrays
        if convert_numpy and hasattr(obj, 'tolist') and 'numpy' in str(
                type(obj)):
            return obj.tolist()

        # Handle sets
        if convert_sets and isinstance(obj, set):
            return [
                make_json_serializable(item, convert_tensors, convert_numpy,
                                       convert_sets, convert_tuples,
                                       handle_errors, max_depth,
                                       _current_depth + 1) for item in obj
            ]

        # Handle tuples
        if convert_tuples and isinstance(obj, tuple):
            return [
                make_json_serializable(item, convert_tensors, convert_numpy,
                                       convert_sets, convert_tuples,
                                       handle_errors, max_depth,
                                       _current_depth + 1) for item in obj
            ]

        # Handle lists
        if isinstance(obj, list):
            result = []
            for i, item in enumerate(obj):
                try:
                    converted_item = make_json_serializable(
                        item, convert_tensors, convert_numpy, convert_sets,
                        convert_tuples, handle_errors, max_depth,
                        _current_depth + 1)
                    if handle_errors != "delete" or converted_item is not None:
                        result.append(converted_item)
                except Exception as e:
                    if handle_errors == "raise":
                        raise
                    elif handle_errors == "warn":
                        print(
                            f"Warning: Could not convert list item at index {i}: {e}"
                        )
                        result.append(item)
                    # "delete" case: skip the item
            return result

        # Handle dictionaries
        if isinstance(obj, dict):
            result = {}
            for key, value in obj.items():
                try:
                    # Convert key to string if it's not JSON-serializable
                    if not isinstance(key, str):
                        key = str(key)

                    converted_value = make_json_serializable(
                        value, convert_tensors, convert_numpy, convert_sets,
                        convert_tuples, handle_errors, max_depth,
                        _current_depth + 1)

                    if handle_errors != "delete" or converted_value is not None:
                        result[key] = converted_value

                except Exception as e:
                    if handle_errors == "raise":
                        raise
                    elif handle_errors == "warn":
                        print(
                            f"Warning: Could not convert dict key '{key}': {e}"
                        )
                        result[key] = value
                    # "delete" case: skip the key-value pair
            return result

        # Try to convert other types to string as fallback
        try:
            import json
            json.dumps(obj)  # Test if already serializable
            return obj
        except (TypeError, ValueError):
            # Not serializable, convert to string representation
            str_repr = str(obj)
            if handle_errors == "warn":
                print(
                    f"Warning: Converting non-serializable object {type(obj)} to string: {str_repr[:100]}..."
                )
            return str_repr

    except Exception as e:
        if handle_errors == "raise":
            raise
        elif handle_errors == "warn":
            print(f"Warning: Could not convert object {type(obj)}: {e}")
            return obj
        else:  # "delete"
            return None
