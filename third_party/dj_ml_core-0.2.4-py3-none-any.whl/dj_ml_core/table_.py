import datajoint as dj
from config_dataclass import Configurable
from datajoint.utils import ClassProperty

from dj_ml_core.fields import CharField, Field, JSONField, ProjectedTableField


class BaseConfigTable(dj.Manual):
    """
    Base class for DataJoint tables that store and manage Configurable objects.
    
    This class provides the foundation for storing configuration data from any
    Configurable class in a DataJoint database table. It handles automatic
    serialization, nested configuration management, and hash-based identification
    of configurations.
    
    The BaseConfigTable serves as the DataJoint extension of Configurable classes,
    bridging the gap between in-memory configuration objects and persistent database
    storage. Each configuration is stored with a unique hash derived from its
    parameters as defined by the Configurable class.
    
    Key Features:
    - Automatic hash generation from configuration dictionaries
    - Support for nested Configurable objects via ProjectedTableField
    - Bidirectional conversion between config dicts and database rows
    - Type validation using Configurable.validate_config_dict()
    - Recursive handling of complex configuration hierarchies
    
    Attributes:
        arg_hash (CharField): Primary key containing the hash of the configuration
        config (JSONField): Serialized configuration dictionary
    
    Example:
        >>> @schema
        ... class ModelConfigTable(BaseConfigTable):
        ...     pass
        ...
        >>> @config_dataclass
        ... class ModelConfig(Configurable):
        ...     learning_rate: float = config_field(default=0.001)
        ...     hidden_dim: int = config_field(default=128)
        ...
        >>> model_config = ModelConfig(learning_rate=0.01, hidden_dim=256)
        >>> table = ModelConfigTable()
        >>> hash_key = table.insert_from_config(model_config.to_dict())
        >>> retrieved_config = table.get_config_dict({'arg_hash': hash_key})
        >>> reconstructed = ModelConfig.from_dict(retrieved_config)
    
    See Also:
        - Configurable: The base class for configuration objects
        - ProjectedTableField: For referencing other BaseConfigTable instances
        - JSONField: For storing serialized configuration data
    """
    arg_hash = CharField(length=128, primary_key=True)
    config = JSONField()

    @property
    def db_fields(self):
        """
        Get all Field instances defined on this table class.
        
        Traverses the method resolution order to collect all Field instances
        defined on this class and its base classes, excluding the base object class.
        
        Returns:
            dict: Mapping of field names to Field instances
        """
        fields = {}
        for base_cls in self.__class__.mro():
            if base_cls is object:  # Stop at the top of the hierarchy
                continue
            for key, value in base_cls.__dict__.items():
                if isinstance(value, Field):
                    fields[key] = value
        return fields

    def insert_from_config(self, config_dict, row_dict={}, **kwargs):
        """
        Insert a configuration dictionary into the table.
        
        Takes a configuration dictionary (typically from Configurable.to_dict()),
        validates it, generates a hash, and stores it in the database. Handles
        nested configurations by recursively inserting them into their respective
        tables via ProjectedTableField relationships.
        
        Args:
            config_dict (dict): Configuration dictionary to insert
            row_dict (dict, optional): Additional fields to include in the row
            **kwargs: Additional arguments passed to DataJoint's insert1()
        
        Returns:
            str: The generated hash key for the inserted configuration
        
        Raises:
            ValueError: If the config_dict fails validation
            
        Example:
            >>> config = {'learning_rate': 0.01, 'hidden_dim': 256}
            >>> hash_key = table.insert_from_config(config, skip_duplicates=True)
        """
        # row is the content dict
        if not Configurable.validate_config_dict(config_dict):
            raise ValueError("Invalid config dictionary")

        # first we create the hash
        arg_hash = Configurable.hash_config_dict(config_dict)
        row = dict(arg_hash=arg_hash, config=config_dict)
        # for manually inserting additional fields
        row.update(row_dict)

        # find any fields that are TableFields and point to another ConfigTable
        for field_name, db_field in self.db_fields.items():
            if isinstance(db_field, ProjectedTableField):
                if issubclass(db_field.table, BaseConfigTable):
                    sub_config = config_dict.pop(field_name)
                    sub_config_kwargs = kwargs.copy()
                    sub_config_kwargs["skip_duplicates"] = True
                    table_ref = db_field.table()
                    row[field_name] = table_ref.insert_from_config(
                        sub_config, **sub_config_kwargs)

        self.insert1(row, **kwargs)
        return arg_hash

    def get_config_dict(self, key=None):
        """
        Retrieve a configuration dictionary from the table.
        
        Fetches a stored configuration and reconstructs nested configurations
        by following ProjectedTableField relationships. The returned dictionary
        can be used with Configurable.from_dict() to reconstruct the original
        configuration object.
        
        Args:
            key (dict, optional): DataJoint key to restrict the query.
                                If None, expects exactly one row in the table.
        
        Returns:
            dict: Complete configuration dictionary with nested configurations resolved
        
        Raises:
            AssertionError: If the query doesn't return exactly one row
            
        Example:
            >>> config_dict = table.get_config_dict({'arg_hash': hash_key})
            >>> model_config = ModelConfig.from_dict(config_dict)
        """
        config_inst = self
        if key is not None:
            config_inst = config_inst & key
        assert len(config_inst) == 1, "Expected a single row"
        row = config_inst.fetch1()
        config = row['config'].copy()

        # find any fields that are TableFields and point to another ConfigTable
        for field_name, db_field in self.db_fields.items():
            if isinstance(db_field, ProjectedTableField):
                if issubclass(db_field.table, BaseConfigTable):
                    table_ref = db_field.table()
                    sub_key = {db_field.key_name: row[field_name]}
                    config[field_name] = table_ref.get_config_dict(sub_key)

        return config

    ### Bugfix required to call .alter() on classes deriving from BaseConfigTable
    # DJ tries to find the class by name from the locals() context, which includes the BaseConfigTable
    # But this class is not registered via the schema decorator by design which leads to a DataJointError being raised
    # To avoid this, we override the full_table_name property to return a table name anyways
    @ClassProperty
    def full_table_name(cls):
        # return constant table name if cls is == BaseConfigTable
        if cls is BaseConfigTable:
            return "BaseConfigTable"
        # otherwise call super() to get the table name
        return super().full_table_name
