import git
import re
from typing import List, Optional
import warnings
# Pattern collections for common file types
img_patterns = [
    r"\.png$",
    r"\.jpg$",
    r"\.jpeg$",
    r"\.gif$",
    r"\.svg$",
]

document_patterns = [
    r"\.txt$",
    r"\.md$",
    r"\.pdf$",
]

data_patterns = [
    r"\.csv$",
    r"\.tsv$",
    r"\.xlsx$",
]

notebook_patterns = [
    r"\.ipynb$",
]

script_patterns = [
    r"\.sh$",
]

# Default ignore patterns (combination of all above)
default_ignore_patterns = (img_patterns + document_patterns + data_patterns +
                           notebook_patterns + script_patterns)


class GitChecker:
    """A class to check git repository status with configurable filtering."""

    def __init__(self,
                 include_patterns: List[str] = [".*"],
                 ignore_patterns: List[str] = default_ignore_patterns,
                 verbose: bool = False,
                 unsafe_hash: bool = False):
        """
        Initialize GitChecker with filtering patterns.
        
        Args:
            include_patterns: List of regex patterns to include files. Defaults to include all files.
            ignore_patterns: List of regex patterns to ignore files.
            verbose: If True, prints detailed information about files.
            unsafe_hash: If True, returns commit hash even with uncommitted changes (with +unsafe suffix).
        """
        self.include_patterns = include_patterns
        self.ignore_patterns = ignore_patterns
        self.verbose = verbose
        self.unsafe_hash = unsafe_hash
        self.repo = git.Repo(search_parent_directories=True)
        if self.unsafe_hash:
            warnings.warn(
                "Unsafe hash is enabled. This will return the commit hash even with uncommitted changes."
            )

    def _matches_patterns(self, filepath: str, patterns: List[str]) -> bool:
        """Check if filepath matches any of the given regex patterns."""
        return any(re.search(pattern, filepath) for pattern in patterns)

    def _filter_files(self, files: List[str]) -> List[str]:
        """
        Filter files based on include and ignore patterns.
        
        Args:
            files: List of file paths to filter
            
        Returns:
            Filtered list of file paths
        """
        # First, filter for files to include
        included_files = [
            f for f in files
            if self._matches_patterns(f, self.include_patterns)
        ]

        # Then, filter out files to ignore
        filtered_files = [
            f for f in included_files
            if not self._matches_patterns(f, self.ignore_patterns)
        ]

        return filtered_files

    def has_untracked_changes(self) -> bool:
        """Check if there are untracked files that match the filtering criteria."""
        untracked_files = self.repo.untracked_files
        filtered_files = self._filter_files(untracked_files)

        if self.verbose and filtered_files:
            print("Untracked files:")
            for file in filtered_files:
                print(f"  {file}")

        return len(filtered_files) > 0

    def has_uncommitted_changes(self) -> bool:
        """Check if there are uncommitted changes that match the filtering criteria."""
        unstaged_diffs = self.repo.index.diff(None)
        staged_diffs = self.repo.index.diff("HEAD")
        diffs = list(unstaged_diffs) + list(staged_diffs)

        diff_files = [diff.a_path for diff in diffs]
        filtered_files = self._filter_files(diff_files)

        if self.verbose and filtered_files:
            print("Uncommitted changes:")
            for file in filtered_files:
                print(f"  {file}")

        return len(filtered_files) > 0

    def check_repo_status(self) -> str:
        """
        Check repository status and return commit hash if clean.
        
        Returns:
            Commit hash if repository is clean, or commit hash with +unsafe suffix if unsafe_hash is True
            
        Raises:
            ValueError: If there are untracked or uncommitted files and unsafe_hash is False
        """
        has_untracked = self.has_untracked_changes()
        has_uncommitted = self.has_uncommitted_changes()

        commit_hash = self.repo.head.object.hexsha

        if not has_untracked and not has_uncommitted:
            return commit_hash
        else:
            if self.unsafe_hash:
                warnings.warn(
                    "UNSAFE COMMIT HASH: There are untracked or uncommitted files."
                )
                return commit_hash + "+unsafe"
            else:
                raise ValueError("There are untracked or uncommitted files.")


def check_repo_status(include_patterns: List[str] = [".*"],
                      ignore_patterns: List[str] = default_ignore_patterns,
                      verbose: bool = False) -> str:
    """
    Convenience function for backward compatibility.
    
    Args:
        include_patterns: List of regex patterns to include files
        ignore_patterns: List of regex patterns to ignore files
        verbose: If True, prints detailed information about files
        
    Returns:
        Commit hash if repository is clean
    """
    checker = GitChecker(include_patterns=include_patterns,
                         ignore_patterns=ignore_patterns,
                         verbose=verbose)
    return checker.check_repo_status()


if __name__ == "__main__":
    print(GitChecker(
        unsafe_hash=True,
        verbose=True,
    ).check_repo_status())
