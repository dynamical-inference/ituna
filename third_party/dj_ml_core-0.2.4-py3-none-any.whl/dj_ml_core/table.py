import datajoint as dj
from datajoint.utils import ClassProperty

from dj_ml_core.fields import CharField, JSONField

try:
    from dj_ml_core.table_ import BaseConfigTable
    _CONFIG_DATACLASS_AVAILABLE = True
except ImportError:
    _CONFIG_DATACLASS_AVAILABLE = False

if not _CONFIG_DATACLASS_AVAILABLE:

    class BaseConfigTable(dj.Manual):
        arg_hash = CharField(length=128, primary_key=True)
        config = JSONField()

        _error = ImportError(
            "Cannot use BaseConfigTable, `config_dataclass` is not installed. "
            "Please install it with `pip install config-dataclass`.")

        @property
        def db_fields(self):
            raise self._error

        def insert_from_config(self, *args, **kwargs):
            raise self._error

        def get_config_dict(self, *args, **kwargs):
            raise self._error

        @ClassProperty
        def full_table_name(cls):
            if cls is BaseConfigTable:
                return "BaseConfigTable"
            return super().full_table_name
