__version__ = '0.2.4'
# defining import order here to make sure query_expression is imported first
# so that the monkey patch is applied before any other imports

import dj_ml_core.core
import dj_ml_core.fields
import dj_ml_core.login
import dj_ml_core.query_expression
import dj_ml_core.table
