from datajoint.expression import QueryExpression
from typing import Optional


def _proj_all(self,
              prefix: Optional[str] = None,
              sep: str = "__",
              skip_primary_key: bool = False,
              **primary_keys):
    """
    Project all attributes with automatic prefixing for join operations.
    
    This method extends DataJoint's proj() operator to automatically project all attributes
    from a table with a consistent naming scheme, which is particularly useful for joining
    configuration tables or creating flattened views of related data.
    
    The method automatically renames all secondary attributes by prefixing them with the
    table name (or custom prefix) and a separator. Primary key handling is flexible,
    allowing for single primary keys to use just the prefix as the name, or multiple
    primary keys to be individually prefixed.
    
    :param prefix: Prefix to use for renaming attributes. If None, uses self.table_name.
    :type prefix: Optional[str]
    :param sep: Separator between prefix and attribute name.
    :type sep: str
    :param skip_primary_key: If True, excludes primary key attributes from projection.
    :type skip_primary_key: bool
    :param primary_keys: Keyword arguments for explicitly renaming specific primary key attributes.
    :return: QueryExpression with all attributes projected and renamed according to the prefix scheme.
    :rtype: QueryExpression
    
    Examples:
        Simple usage with default table name as prefix:
        >>> table.proj_all()
        # Projects all attributes prefixed with table name
        
        Custom prefix:
        >>> table.proj_all(prefix="custom")
        # All secondary attributes become "custom__attr_name"
        
        Custom separator:
        >>> table.proj_all(prefix="tbl", sep="_")
        # All secondary attributes become "tbl_attr_name"
        
        Skip primary keys:
        >>> table.proj_all(skip_primary_key=True)
        # Only projects secondary attributes
        
        Explicit primary key renaming:
        >>> table.proj_all(custom_pk="original_pk_name")
        # Renames specific primary key while auto-handling others
        
        Typical use case for joining config tables:
        >>> (ExperimentConfigTable() * 
        ...  DatasetConfigTable().proj_all(prefix="dataset") * 
        ...  TrainerConfigTable().proj_all(prefix="trainer"))
        # Creates a flattened view with all config attributes properly namespaced
    
    Note:
        This method is particularly useful when working with BaseConfigTable subclasses
        where you want to join multiple configuration tables. Since all BaseConfigTables use the arg_hash attribute as the primary key,
        the automatic prefixing ensures that attributes from different tables can be correctly used as foreign keys for the following join operations.
        
        Special handling for 'arg_hash' primary keys: When a table has multiple primary
        keys including 'arg_hash', the 'arg_hash' key is renamed to just the prefix
        (without separator) while other primary keys get the full prefix + separator treatment.
    """
    if prefix is None:
        prefix = self.table_name
    named_attributes = {
        f"{prefix}{sep}{attr}": attr
        for attr in self.heading.secondary_attributes
    }

    if not skip_primary_key:
        if len(self.heading.primary_key) == 1:
            # if there's a single primary key we use the prefix as the key name
            named_attributes[f"{prefix}"] = self.heading.primary_key[0]
        else:
            primary_attributes = {}
            for key in self.heading.primary_key:
                if key in primary_keys.values():
                    # don't automatically rename primary keys that have explicitly been renamed
                    continue
                elif key == "arg_hash":
                    primary_attributes[f"{prefix}"] = "arg_hash"
                else:
                    primary_attributes[f"{prefix}{sep}{key}"] = key

            named_attributes.update(primary_attributes)
            named_attributes.update(primary_keys)

    return self.proj(**named_attributes)


QueryExpression.proj_all = _proj_all
