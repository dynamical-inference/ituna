"""
ConfigClass - A Python package for creating configurable dataclasses with automatic 
serialization, validation, and reproducible configuration management.
"""

from .core import Configurable, LazyInitializable, check_initialized, config_dataclass
from .exceptions import ConfigurationError, InitializationError, ValidationError
from .fields import config_field, state_field
from .torch import ConfigurableTorchModule, StateDictStorageMixin, torch_dataclass

__version__ = "0.3.0"
__author__ = "Tobias Schmidt"

__all__ = [
    # Core classes
    "LazyInitializable",
    "Configurable",
    "config_dataclass",

    # Torch classes
    "ConfigurableTorchModule",
    "torch_dataclass",
    "StateDictStorageMixin",

    # Field helpers
    "config_field",
    "state_field",

    # Decorators and utilities
    "check_initialized",

    # Exceptions
    "ConfigurationError",
    "ValidationError",
    "InitializationError",
]
