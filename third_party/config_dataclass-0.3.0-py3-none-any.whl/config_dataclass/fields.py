"""
Field helper functions for creating different types of dataclass fields.
"""

from dataclasses import field
from typing import Any, Optional


def _make_field(field_type: str,
                help: Optional[str] = None,
                skip_default: Optional[bool] = None,
                **kwargs) -> Any:
    """Helper function to create a field with specified metadata type.

    Args:
        field_type: Type of field ("config" or "state")
        help: Optional help string describing the field
        skip_default: If True, skip this field's default value when computing hashes
        **kwargs: Additional field arguments to pass to field()

    Returns:
        Field with metadata type set to specified type
    """
    metadata = {"type": field_type}
    if "metadata" in kwargs:
        metadata.update(kwargs.pop("metadata"))
    if help:
        metadata["help"] = help
    if skip_default:
        metadata["skip_default"] = skip_default
    return field(metadata=metadata, **kwargs)


def config_field(help: Optional[str] = None,
                 skip_default: Optional[bool] = None,
                 **kwargs) -> Any:
    """Field decorator that marks a dataclass field as configuration.
    
    Configuration fields are:
    - Included in serialization via to_dict()
    - Used for configuration hashing  
    - Subject to type validation
    - Part of the core configuration that defines object behavior
    
    Args:
        help: Optional help string describing the field
        skip_default: If True, skip this field's default value when computing hashes
        **kwargs: Additional field arguments (default, default_factory, etc.)
        
    Returns:
        Dataclass field with config metadata
        
    Example:
        @config_dataclass
        class MyConfig(Configurable):
            learning_rate: float = config_field(default=0.001, help="Learning rate")
            batch_size: int = config_field(default=32)
    """
    return _make_field("config",
                       help=help,
                       skip_default=skip_default,
                       **kwargs)


def state_field(repr: bool = False, **kwargs) -> Any:
    """Field decorator that marks a dataclass field as state.

    State fields are:
    - NOT passed to the __init__ method
    - NOT included in serialization via to_dict()
    - NOT used for configuration hashing
    - NOT subject to type validation during config validation or during __init__ type checking
    - Used for tracking internal object state
    - Included in the .state property
    - Stored/restored to/from disk when .save()/.load() is called
    
    Args:
        repr: Whether to include this field in __repr__. Defaults to False.
        **kwargs: Additional field arguments (default, default_factory, etc.)
        
    Returns:
        Dataclass field with state metadata
        
    Example:
        @config_dataclass
        class MyConfig(Configurable):
            _training_step: int = state_field(default=0, repr=True)
            _internal_cache: dict = state_field(default_factory=dict)
    """
    return _make_field("state", init=False, repr=repr, **kwargs)
