import torch
from .core import Configurable

from dataclasses import dataclass, fields
import typing
from typing import get_origin, get_args
from pathlib import Path


def torch_dataclass(cls):
    """
    A decorator that applies the standard dataclass configuration for torch modules.
    Equivalent to @dataclass(unsafe_hash=True, eq=False, kw_only=True)
    """
    decorated_cls = dataclass(unsafe_hash=True, eq=False, kw_only=True)(cls)

    # Torch modules require the class to be hashable.
    # unsafe_hash=True forces the creation of a hash function, but requires that the fields are hashable.
    # In particular, this is not the case when a field is of type list or dict
    # So we need to check for this and raise an error to suggest alternatives.

    def _contains_unhashable_type(type_annotation):
        """Recursively check if a type annotation contains unhashable types (list or dict)."""
        # Direct type checks
        if type_annotation is list or type_annotation is dict:
            return 'list' if type_annotation is list else 'dict'

        # Check for typing.List and typing.Dict
        if hasattr(typing, 'List') and type_annotation is typing.List:
            return 'list'
        if hasattr(typing, 'Dict') and type_annotation is typing.Dict:
            return 'dict'

        # Get the origin type for generic types (e.g., List[int] -> list, Dict[str, int] -> dict)
        origin = get_origin(type_annotation)
        if origin is list:
            return 'list'
        if origin is dict:
            return 'dict'

        # For Union types (including Optional which is Union[T, None])
        if origin is typing.Union:
            args = get_args(type_annotation)
            for arg in args:
                result = _contains_unhashable_type(arg)
                if result:
                    return result

        return False

    for field in fields(decorated_cls):
        unhashable_type = _contains_unhashable_type(field.type)
        if unhashable_type == 'list':
            raise ValueError(
                f"Field {field.name} contains list type, which is not hashable. Please use tuple instead."
            )
        elif unhashable_type == 'dict':
            raise ValueError(
                f"Field {field.name} contains dict type, which is not hashable. Please encapsulate the logic in a nested configurable object instead."
            )

    return decorated_cls


class StateDictStorageMixin:

    def _save_additional(self, path: Path):
        torch.save(self.state_dict(), path / "state_dict.pt")

    def _load_additional(self, path: Path):
        state_dict_file = path / "state_dict.pt"
        if state_dict_file.exists():
            self.load_state_dict(
                torch.load(
                    state_dict_file,
                    weights_only=False,
                    map_location=torch.device('cpu'),
                ))


@torch_dataclass
class ConfigurableTorchModule(StateDictStorageMixin, Configurable):
    """
    A Configurable class that is compatible with torch.nn.Module.

    Usage: 
    @torch_dataclass
    class MyModel(ConfigurableTorchModule, torch.nn.Module):
        ...
        def __lazy_post_init__(self):
            ...
            self.network = torch.nn.Sequential(...)

    model = MyModel()
    model.save("path/to/model")
    model.load("path/to/model")
    """

    def __new__(cls, *args, **kwargs):
        """
        Handles the diamond inheritance issue between Configurable and nn.Module.
        This special method ensures that both parent classes are initialized correctly.
        """
        # Create the instance using Configurable's __new__
        instance = super().__new__(cls)
        # Manually call nn.Module's initializer on the new instance
        torch.nn.Module.__init__(instance)
        return instance
