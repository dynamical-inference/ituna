"""
Core classes for ConfigClass package.
"""

import hashlib
import importlib
import json
import warnings
from dataclasses import _MISSING_TYPE, Field, dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, TypeVar, Union

from filelock import FileLock
from typeguard import check_type

from .exceptions import ConfigurationError, InitializationError, ValidationError

T = TypeVar("T")


def hash_key(s: str) -> str:
    """Generate a short hash from a string."""
    hash_value = hashlib.md5(s.encode()).hexdigest()
    return hash_value


def check_initialized(func):
    """Function decorator to check if class is initialized."""

    def wrapper(self, *args, **kwargs):
        if not self.initialized:
            raise InitializationError(
                f"Class {self.__class__.__name__} not initialized. Call .lazy_init() first."
            )
        return func(self, *args, **kwargs)

    return wrapper


def config_dataclass(cls=None, /, **kwargs):
    """
    A decorator that applies the standard dataclass configuration for configurable objects.
    Specifically we want to set kw_only=True to avoid any issues with positional arguments that may arise when making use of inheritance.
    
    Args:
        cls: The class to decorate (when used without parentheses)
        **kwargs: Additional keyword arguments to pass to the dataclass decorator
    """
    # Set default kw_only=True but allow it to be overridden
    dataclass_kwargs = {'kw_only': True}
    dataclass_kwargs.update(kwargs)

    def wrap(cls):
        return dataclass(**dataclass_kwargs)(cls)

    # Handle both @config_dataclass and @config_dataclass() usage patterns
    if cls is None:
        # Called as @config_dataclass() with parentheses
        return wrap

    # Called as @config_dataclass without parentheses
    return wrap(cls)


@config_dataclass
class LazyInitializable:
    """Base class providing lazy initialization functionality.
    
    This class allows objects to be created without full initialization,
    deferring expensive operations until explicitly requested via lazy_init().
    
    Attributes:
        lazy: If True, skip automatic initialization in __post_init__
        _initialized: Internal flag tracking initialization state
    """
    lazy: bool = field(default=False)
    _initialized: bool = field(default=False, init=False, repr=False)

    @property
    def initialized(self) -> bool:
        """Whether the object has been initialized."""
        return self._initialized

    def __lazy_post_init__(self, *args, **kwargs):
        """Override this method to perform lazy initialization logic.
        
        This method is called when lazy_init() is invoked.
        """
        pass

    def validate_config(self):
        """Override this method to perform configuration validation.
        
        This method is called during __post_init__ before any initialization.
        """
        pass

    def validate_config_post_init(self):
        """Override this method to perform post-initialization validation.
        
        This method is called after lazy initialization is complete.
        """
        pass

    def lazy_init(self, *args, **kwargs):
        """Perform lazy initialization.
        
        Args:
            *args, **kwargs: Arguments passed to __lazy_post_init__
        """
        self._initialized = True
        self.__lazy_post_init__(*args, **kwargs)
        self.validate_config_post_init()

    def __post_init__(self):
        """Dataclass post-init hook."""
        self.validate_config()
        if not self.lazy:
            self.lazy_init()


class Configurable(LazyInitializable):
    """Class for configurable dataclass objects.
    
    This class provides automatic serialization, validation, and registry
    functionality for dataclass objects. Only fields marked with config_field()
    are considered part of the configuration.
    
    Features:
    - Automatic class registry
    - Configuration serialization/deserialization  
    - Type validation
    - Configuration hashing for reproducibility
    - File save/load with locking
    - Support for nested configurable objects
    """

    _registry: Dict[str, Any] = {}

    @classmethod
    def config_prefix(cls) -> str:
        """Prefix for the configuration file.
        
        Converts CamelCase class names to snake_case.
        """
        camel_case_name = cls.__name__
        # Convert camel case to snake case
        return ''.join([
            '_' + i.lower() if i.isupper() else i for i in camel_case_name
        ]).lstrip('_')

    @property
    def config(self) -> Dict[str, Any]:
        """Get all configuration attributes.
        
        Returns:
            Dictionary containing all fields marked as config fields
        """
        config_dict = {}
        for f in fields(self):
            if f.metadata.get("type") == "config":
                config_dict[f.name] = getattr(self, f.name)
        return config_dict

    @staticmethod
    def config_fields(class_name: str) -> List[Field]:
        """Get the fields that are config fields for a given class.
        
        Args:
            class_name: Name of the class to get config fields for
            
        Returns:
            List of Field objects that are marked as config fields
        """
        return [
            f for f in fields(Configurable._registry[class_name])
            if f.metadata.get("type") == "config"
        ]

    @property
    def state(self) -> Dict[str, Any]:
        """Get all state attributes.
        
        Returns:
            Dictionary containing all fields marked as state fields
        """
        state_dict = {}
        for f in fields(self):
            if f.metadata.get("type") == "state":
                state_dict[f.name] = getattr(self, f.name)
        return state_dict

    @staticmethod
    def state_fields(class_name: str) -> List[Field]:
        """Get the fields that are state fields for a given class.
        
        Args:
            class_name: Name of the class to get state fields for

        Returns:
            List of Field objects that are marked as state fields
        """
        return [
            f for f in fields(Configurable._registry[class_name])
            if f.metadata.get("type") == "state"
        ]

    @property
    def config_hash(self) -> str:
        """Hash of the configuration, taking into account sub-configs.
        
        Returns:
            MD5 hash string of the configuration
        """
        config_dict = self.to_dict()
        return Configurable.hash_config_dict(config_dict)

    @staticmethod
    def hash_config_dict(config_dict: Dict[str, Any]) -> str:
        """Hash of the configuration, taking into account sub-configs.
        
        Args:
            config_dict: Configuration dictionary to hash
            
        Returns:
            MD5 hash string of the configuration
        """
        hash_dict = {}
        for key, value in config_dict.items():
            # Check if value is a Configurable object
            if isinstance(value, dict) and "class_type" in value:
                class_type = value["class_type"]
                if class_type not in Configurable._registry:
                    raise ConfigurationError(
                        f"Class {class_type} not registered")
                hash_dict[key] = Configurable.hash_config_dict(value)
            else:
                # Get the field info to check if skip_default is set
                class_type = config_dict["class_type"]
                if class_type not in Configurable._registry:
                    raise ConfigurationError(
                        f"Class {class_type} not registered")
                the_class = Configurable._registry[class_type]
                if key != "class_type":
                    field_info = None
                    for f in fields(the_class):
                        if f.name == key:
                            field_info = f
                            break

                    if field_info and field_info.metadata.get("skip_default"):
                        if value == field_info.default:
                            # Skip default values if skip_default is True
                            continue
                        elif field_info.default is _MISSING_TYPE:
                            raise ValueError(
                                f"skip_default is set to True but field {key} doesn't have a default value"
                            )

                hash_dict[key] = value

        return hash_key(json.dumps(hash_dict, sort_keys=True))

    @classmethod
    def config_name(cls) -> str:
        """Name of the configuration file."""
        return "config.json"

    def __init_subclass__(cls, **kwargs):
        """Automatically register subclasses in the registry."""
        super().__init_subclass__(**kwargs)
        if cls.__name__ in cls._registry:
            warnings.warn(
                f"Duplicate Config class {cls.__name__}. Overwriting existing class in registry."
            )
        Configurable._registry[cls.__name__] = cls

    def to_dict(self) -> Dict[str, Any]:
        """Convert the configuration to a dictionary that is json serializable.
        
        Recursively converts nested Configurable objects to dictionaries.
        
        Returns:
            Dictionary representation of the configuration
        """
        config_dict = self.config.copy()

        # we need to convert tuples to lists first
        for key in config_dict.keys():
            if isinstance(config_dict[key], tuple):
                config_dict[key] = list(config_dict[key])

        for key, value in config_dict.items():

            # Handle configurable objects
            if isinstance(value, Configurable):
                config_dict[key] = value.to_dict()
            elif isinstance(value, list) and all(
                    isinstance(item, Configurable) for item in value):
                config_dict[key] = [item.to_dict() for item in value]
            elif isinstance(value, dict) and all(
                    isinstance(item, Configurable) for item in value.values()):
                config_dict[key] = {k: v.to_dict() for k, v in value.items()}
            else:
                # Check if this is supposed to be a Configurable but got corrupted
                field_info = None
                for f in fields(self):
                    if f.name == key:
                        field_info = f
                        break

                if field_info and hasattr(field_info.type, '__origin__'):
                    # Handle generic types like List[SomeClass] or Dict[str, SomeClass]
                    continue
                elif field_info and hasattr(field_info.type, '__mro__'):
                    # Check if the field type is supposed to be a Configurable
                    if (hasattr(field_info.type, '__mro__') and any(
                            issubclass(base, Configurable)
                            for base in field_info.type.__mro__
                            if isinstance(base, type))):
                        if not isinstance(value, field_info.type):
                            raise TypeError(
                                f"Field '{key}' expected type {field_info.type}, got {type(value)}"
                            )

        # Add type to config
        config_dict["class_type"] = self.__class__.__name__
        config_dict["module_name"] = self.__class__.__module__
        return config_dict

    def clone(self: T, lazy: Optional[bool] = None) -> T:
        """Clone the object.
        Args:
            lazy: Override lazy initialization setting

        Returns:
            New instance with the same configuration
        """
        return self.from_dict(self.to_dict(), lazy=lazy)

    def save(self, path: Union[Path, str]) -> Path:
        """Save configuration and additional data to disk.
        
        This method saves both the configuration (via to_dict()) and any additional
        data through the _save_additional() hook. This allows subclasses to save
        state beyond just the configuration (e.g., model weights, cached data).
        
        Args:
            path: Directory path to save configuration
            
        Returns:
            Path to the saved configuration file
        """
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        lock = FileLock(path / "lock.lock", timeout=10)
        lock.acquire()
        try:
            nested_config_dict = self.to_dict()
            config_path = path / self.__class__.config_name()
            with open(config_path, 'w') as f:
                json.dump(nested_config_dict, f, indent=4)

            self._recursive_save_additional(path)
        finally:
            lock.release(force=True)
            # Clean up lock file if it still exists
            lock_file = path / "lock.lock"
            if lock_file.exists():
                lock_file.unlink()
        return config_path

    def _recursive_save_additional(self, path: Path):
        """Recursively save additional data for nested objects."""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        self._save_state(path)
        self._save_additional(path)
        for key, value in self.config.items():
            if isinstance(value, Configurable):
                # Create a new path for additional save
                sub_path = path / f"{key}/"
                value._recursive_save_additional(sub_path)
            elif isinstance(value, (list, tuple)):
                is_configurable_list = [
                    isinstance(item, Configurable) for item in value
                ]
                if any(is_configurable_list):
                    if not all(is_configurable_list):
                        raise ConfigurationError(
                            f"Field '{key}' contains a mix of Configurable and non-Configurable "
                            f"types in a list/tuple. This is not supported for saving "
                            f"additional data.")
                    # All items are Configurable
                    list_path = path / f"{key}/"
                    for i, item in enumerate(value):
                        sub_path = list_path / f"{i}/"
                        item._recursive_save_additional(sub_path)
            elif isinstance(value, dict):
                is_configurable_dict = [
                    isinstance(item, Configurable) for item in value.values()
                ]
                if any(is_configurable_dict):
                    if not all(is_configurable_dict):
                        raise ConfigurationError(
                            f"Field '{key}' contains a mix of Configurable and non-Configurable "
                            f"types in a dict. This is not supported for saving "
                            f"additional data.")
                    # All items are Configurable
                    dict_path = path / f"{key}/"
                    for dict_key, dict_item in value.items():
                        sub_path = dict_path / f"{dict_key}/"
                        dict_item._recursive_save_additional(sub_path)

    def _save_additional(self, path: Path):
        """Hook for saving additional data beyond the configuration.
        
        Override this method in subclasses to save state that goes beyond
        the configuration fields, such as:
        - Model weights and parameters
        - Cached computations
        - Large data structures
        - External resources
        
        This method is called during save() after the configuration is saved.
        
        Args:
            path: Directory path where additional data should be saved
        """
        pass

    def _save_state(self, path: Path):
        """Save state fields as JSON.
        
        This method automatically handles the serialization of all fields marked
        with state_field(). Override this method if you need custom state
        serialization logic.
        
        Args:
            path: Directory path where state should be saved
        """
        state_data = self.state
        if state_data:  # Only save if there's actual state data
            state_file = path / "state.json"
            try:
                with open(state_file, 'w') as f:
                    json.dump(state_data, f, indent=2)
            except (TypeError, ValueError) as e:
                raise RuntimeError(
                    f"Failed to serialize state for {self.__class__.__name__}: {str(e)}. "
                    f"State contains non-JSON-serializable objects. "
                    f"Please override _save_state() method "
                    f"to handle custom state serialization.") from e

    @classmethod
    def validate_config_dict(cls, config_dict: Dict[str, Any]) -> bool:
        """Validate the config dictionary.

        Args:
            config_dict: Dictionary containing configuration values

        Returns:
            True if valid

        Raises:
            ValidationError: If config is invalid with detailed error message
        """
        # Get all config fields for this class
        if "class_type" not in config_dict:
            raise ValidationError(
                "Config dictionary must contain 'class_type' field")

        class_name = config_dict["class_type"]

        config_fields = Configurable.config_fields(class_name)

        # Check that all required fields are present
        for f in config_fields:
            if f.name not in config_dict:
                if f.default is _MISSING_TYPE and f.default_factory is _MISSING_TYPE:
                    raise ValidationError(
                        f"Required field '{f.name}' is missing from config for class '{class_name}'"
                    )
                continue

            # If field exists, validate its type
            value = config_dict[f.name]

            # Handle nested Configurable objects
            if isinstance(value, dict) and "class_type" in value:
                # Verify the class type exists in registry
                class_type = value["class_type"]
                if class_type not in Configurable._registry:
                    raise ValidationError(
                        f"Unknown class type '{class_type}' in nested config for field '{f.name}'"
                    )

                # Recursively validate nested config
                nested_cls = Configurable._registry[class_type]
                try:
                    nested_cls.validate_config_dict(value)
                except ValidationError as e:
                    raise ValidationError(
                        f"Invalid nested config for field '{f.name}': {str(e)}"
                    )
            # Handle nested lists of Configurables
            elif isinstance(value, list) and all(
                    isinstance(item, dict) and item.get("class_type")
                    for item in value):
                for item in value:
                    class_type = item["class_type"]
                    if class_type not in Configurable._registry:
                        raise ValidationError(
                            f"Unknown class type '{class_type}' in nested config list for field '{f.name}'"
                        )
                    nested_cls = Configurable._registry[class_type]
                    try:
                        nested_cls.validate_config_dict(item)
                    except ValidationError as e:
                        raise ValidationError(
                            f"Invalid nested config for field '{f.name}': {str(e)}"
                        )
            # Handle nested dicts of Configurables
            elif isinstance(value, dict) and all(
                    isinstance(item, dict) and item.get("class_type")
                    for item in value.values()):
                for k, v in value.items():
                    class_type = v["class_type"]
                    if class_type not in Configurable._registry:
                        raise ValidationError(
                            f"Unknown class type '{class_type}' in nested config dict for field '{f.name}', key '{k}'"
                        )
                    nested_cls = Configurable._registry[class_type]
                    try:
                        nested_cls.validate_config_dict(v)
                    except ValidationError as e:
                        raise ValidationError(
                            f"Invalid nested config for field '{f.name}', key '{k}': {str(e)}"
                        )
            # Type check for non-nested values
            else:
                try:
                    value_to_check = value
                    # Special handling for tuples deserialized from JSON (as lists)
                    if isinstance(value, list):
                        is_simple_tuple = f.type == tuple
                        is_typed_tuple = (hasattr(f.type, '__origin__')
                                          and f.type.__origin__ is tuple)
                        if is_simple_tuple or is_typed_tuple:
                            value_to_check = tuple(value)

                    check_type(value_to_check, f.type)
                except Exception as e:
                    raise ValidationError(
                        f"Type validation failed for field '{f.name}' in class '{class_name}': {str(e)}"
                    )
        return True

    @classmethod
    def _try_import_class(cls, config_dict):
        """Try to import the class if it is not in the registry. Only supported if config_dict contains module_name."""
        class_name = config_dict["class_type"]

        # check if class_name is in registry
        # if not, it may not have been imported yet, so let's try to import it
        if class_name not in Configurable._registry and "module_name" in config_dict:
            try:
                module_name = config_dict["module_name"]
                importlib.import_module(module_name)
            except ImportError:
                raise ValidationError(
                    f"Module {module_name} not found for class {class_name}")

    @classmethod
    def from_dict(
        cls: T,
        config: Dict[str, Any],
        kwargs: Optional[Dict[str, Any]] = None,
        lazy: Optional[bool] = None,
        path: Optional[Path] = None,
    ) -> T:
        """Load object from dictionary.
        
        Args:
            config: Configuration dictionary
            kwargs: Additional kwargs for specific class types
            lazy: Override lazy initialization setting
            path: Path for loading additional data
            
        Returns:
            Configurable instance
        """

        config = config.copy()
        initialized_config = {}

        if "class_type" not in config:
            raise ValidationError("Config must contain a class_type")

        cls._try_import_class(config)

        object_type = config.pop("class_type")
        config.pop("module_name", None)
        # Get the target class from the registry
        if object_type not in cls._registry:
            raise ConfigurationError(
                f"Config class '{object_type}' is not registered")

        target_class = cls._registry[object_type]

        # Validate the config dictionary before processing
        target_class.validate_config_dict({
            **config, "class_type": object_type
        })

        for key, value in config.items():
            if isinstance(value, dict) and value.get("class_type"):
                object_class = Configurable._registry[value["class_type"]]
                initialized_config[key] = object_class.from_dict(value,
                                                                 kwargs=kwargs,
                                                                 lazy=lazy)
            elif isinstance(value, list) and all(
                    isinstance(item, dict) and item.get("class_type")
                    for item in value):
                initialized_config[key] = [
                    Configurable._registry[item["class_type"]].from_dict(
                        item, kwargs=kwargs, lazy=lazy) for item in value
                ]
            elif isinstance(value, dict) and all(
                    isinstance(item, dict) and item.get("class_type")
                    for item in value.values()):
                initialized_config[key] = {
                    k:
                    Configurable._registry[v["class_type"]].from_dict(
                        v, kwargs=kwargs, lazy=lazy)
                    for k, v in value.items()
                }
            else:
                initialized_config[key] = value

        for key, value in initialized_config.items():
            # Handle tuple conversion for JSON serialization
            field_info = next(
                (f for f in fields(target_class) if f.name == key), None)
            if field_info and hasattr(
                    field_info.type,
                    '__origin__') and field_info.type.__origin__ is tuple:
                initialized_config[key] = tuple(value)

        instance_kwargs = kwargs.get(object_type,
                                     {}) if kwargs is not None else {}
        if lazy is not None:
            instance_kwargs["lazy"] = lazy

        instance = target_class(**initialized_config, **instance_kwargs)
        if path is not None:
            instance.locked_recursive_load_additional(path)
        return instance

    @classmethod
    def load(cls: Type[T], path: Union[Path, str], **kwargs) -> T:
        """Load configuration and additional data from disk.
        
        This method loads both the configuration (via from_dict()) and any additional
        data through the _load_additional() hook. This allows subclasses to load
        state beyond just the configuration (e.g., model weights, cached data).
        
        Args:
            path: Directory path containing configuration
            **kwargs: Additional arguments for from_dict
            
        Returns:
            Loaded Configurable instance with additional data restored
        """
        path = Path(path)
        config_path = path / cls.config_name()
        with open(config_path, 'r') as f:
            config = json.load(f)
        instance = cls.from_dict(config, path=path, **kwargs)
        return instance

    def _load_additional(self, path: Path):
        """Hook for loading additional data beyond the configuration.
        
        Override this method in subclasses to load state that goes beyond
        the configuration fields, such as:
        - Model weights and parameters
        - Cached computations
        - Large data structures
        - External resources
        
        This method is called during load() after the configuration is loaded
        and the object is constructed.
        
        Args:
            path: Directory path where additional data is stored
        """
        pass

    def _load_state(self, path: Path):
        """Load state fields from JSON.
        
        This method automatically handles the deserialization of all fields marked
        with state_field(). Override this method if you need custom state
        deserialization logic.
        
        Args:
            path: Directory path where state data is stored
        """
        state_file = path / "state.json"
        if state_file.exists():
            try:
                with open(state_file, 'r') as f:
                    state_data = json.load(f)

                # Restore state fields
                for field_name, value in state_data.items():
                    if hasattr(self, field_name):
                        setattr(self, field_name, value)
                    else:
                        state_fields = Configurable.state_fields(
                            self.__class__.__name__)
                        raise ConfigurationError(
                            f"State field {field_name} not found in {self.__class__.__name__}. "
                            f"Expected state fields: {state_fields}"
                            f"Please check the file or override _load_state() method "
                            f"for custom state deserialization.")

            except (json.JSONDecodeError, ValueError) as e:
                raise RuntimeError(
                    f"Failed to deserialize state for {self.__class__.__name__}: {str(e)}. "
                    f"The state.json file may be corrupted or contain invalid JSON. "
                    f"Please check the file or override _load_state() method "
                    f"for custom state deserialization.") from e
        else:
            state_fields = Configurable.state_fields(self.__class__.__name__)
            if len(state_fields) > 0:
                warnings.warn(
                    f"State file {state_file} does not exist. But class has state fields: {state_fields}"
                    f"Please check the file or override _load_state() method "
                    f"for custom state deserialization.")

    def _recursive_load_additional(self, path: Path):
        """Recursively load additional data for nested objects."""
        self._load_state(path)
        self._load_additional(path)
        for key, value in self.config.items():
            if isinstance(value, Configurable):
                # Create a new path for additional load
                sub_path = path / f"{key}/"
                value._recursive_load_additional(sub_path)
            elif isinstance(value, (list, tuple)):
                if all(isinstance(item, Configurable) for item in value):
                    list_path = path / f"{key}/"
                    for i, item in enumerate(value):
                        sub_path = list_path / f"{i}/"
                        if sub_path.exists():
                            item._recursive_load_additional(sub_path)
                        else:
                            raise ConfigurationError(
                                f"Directory {sub_path} not found for loading additional "
                                f"data for item {i} in '{key}'.")
            elif isinstance(value, dict):
                if all(
                        isinstance(item, Configurable)
                        for item in value.values()):
                    dict_path = path / f"{key}/"
                    for dict_key, dict_item in value.items():
                        sub_path = dict_path / f"{dict_key}/"
                        if sub_path.exists():
                            dict_item._recursive_load_additional(sub_path)
                        else:
                            raise ConfigurationError(
                                f"Directory {sub_path} not found for loading additional "
                                f"data for key '{dict_key}' in '{key}'.")

    def locked_recursive_load_additional(self, path: Path, timeout: int = 10):
        """Load additional data with file locking."""
        lock = FileLock(path / "lock.lock", timeout=timeout)
        lock.acquire()
        try:
            self._recursive_load_additional(path)
        finally:
            lock.release(force=True)
