"""
Custom exceptions for ConfigClass package.
"""


class ConfigurationError(Exception):
    """Raised when there's an error in configuration setup or usage."""
    pass


class ValidationError(Exception):
    """Raised when configuration validation fails."""
    pass


class InitializationError(Exception):
    """Raised when there's an error during lazy initialization."""
    pass
